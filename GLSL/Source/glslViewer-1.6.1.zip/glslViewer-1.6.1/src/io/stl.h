#pragma once

#include "../scene/model.h"

bool loadSTL(WatchFileList& _files, Materials& _materials, Models& _models, int _index, bool _verbose);